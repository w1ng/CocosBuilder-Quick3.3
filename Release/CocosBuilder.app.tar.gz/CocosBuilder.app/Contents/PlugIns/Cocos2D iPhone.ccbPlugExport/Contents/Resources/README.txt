This folder contains some sample formatters that may be helpful.

Feel free to change them, extend them, or use them as the basis for your own custom formatter(s).

More information about creating your own custom formatters can be found on the wiki:
https://github.com/robbiehanson/CocoaLumberjack/wiki/CustomFormatters

