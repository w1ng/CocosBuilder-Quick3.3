require "Cocos2d"
require "Cocos2dConstants"

local GameScene = class("GameScene",function()
    return cc.Scene:create()
end)

function GameScene.create()
    local scene = GameScene.new()
    scene:addChild(require("UI.ccb.MainLayer"):new())
    return scene
end


function GameScene:ctor()
end

return GameScene
