local CCBLoader = require("CCB.Loader")
local Oop = require("Oop.init")

--[[
Callbacks:
    "onPressButton",

Members:
    self.subNode CCBFile
]]
local MainLayer = Oop.class("MainLayer", function(owner)
    -- @param "UI.ccb" => code root
    -- @param "ccb/"   => ccbi folder
    CCBLoader:setRootPath("UI.ccb", "ccb/")
    return CCBLoader:load("MainLayer", owner)
end)

function MainLayer:ctor()
    print("MainLayer:ctor", self, self.subNode)
end

function MainLayer:onPressButton(sender, event)
    print("MainLayer:onPressButton")
    self.subNode.helloLabel:setString("Hello From MainLayer")
end

return MainLayer