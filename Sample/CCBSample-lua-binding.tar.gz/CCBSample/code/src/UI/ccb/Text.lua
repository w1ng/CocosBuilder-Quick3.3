local CCBLoader = require("CCB.Loader")
local Oop = require("Oop.init")

--[[
Callbacks:
    

Members:
    self.helloLabel CCLabelTTF
]]
local Text = Oop.class("Text", function(owner)
    -- @param "UI.ccb" => code root
    -- @param "ccb/"   => ccbi folder
    CCBLoader:setRootPath("UI.ccb", "ccb/")
    return CCBLoader:load("Text", owner)
end)

function Text:ctor()
    print("Text:ctor", self, self.helloLabel)
end



return Text